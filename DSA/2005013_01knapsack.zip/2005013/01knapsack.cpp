#include <bits/stdc++.h>
#define lli long long
#define plli pair<lli, lli>
#define MAX 1003LL
#define MOD 1000000007

#define cout out
#define cin in

using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");


    lli n,cap;
    cin>>n;

    vector<lli> weight(n+1);
    vector<lli> value(n+1);

    

    for(lli j=1;j<=n;j++)
    {
        cin>>weight[j]>>value[j];
    }
    cin>>cap;
    lli dp[n+1][cap+1];
    //dp[0][0]=0;

    for(lli j=0;j<=cap;j++)
    {
        dp[0][j]=0;
    }
    for(lli i=0;i<=n;i++)
    {
        dp[i][0]=0;
    }

    for(lli i=1;i<=n;i++)
    {
        for(lli j=1;j<=cap;j++)
        {
            dp[i][j]=dp[i-1][j];
            if((weight[i]<=cap) && (j-weight[i])>=0)
            {
                dp[i][j]=max(dp[i][j],dp[i-1][j-weight[i]]+value[i]);
            }
        }
    }
    stack<lli> path;
    lli now=cap;
    for(lli i=n;i>0;i--)
    {
        if(dp[i][now]==dp[i-1][now])
        {
            continue;
        }

        else
        {
            now=now-weight[i];
            path.push(weight[i]);
        }

        

    }
    //  for(lli i=0;i<=n;i++)
    // {
    //     for(lli j=0;j<=cap;j++)
    //     {
    //         cout<<dp[i][j]<<" ";
            
    //     }
    //     cout<<"\n";
    // }

    cout<<dp[n][cap]<<"\n";

    while(!path.empty())
    {
        cout<<path.top()<<" ";
        path.pop();
    }
    
}